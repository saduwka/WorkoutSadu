import SwiftData
import Foundation

// MARK: - Gamification Models

struct WeeklyStreak {
    let current: Int
    let record: Int
    let completedThisWeek: Int
    let goalPerWeek: Int
    let weekHistory: [Bool]   // last 6 weeks (true = completed)
    let daysLeftInWeek: Int

    var progressText: String {
        let remaining = max(0, goalPerWeek - completedThisWeek)
        if remaining == 0 { return "Неделя закрыта! 🎉" }
        return "Ещё \(remaining) тр. до цели"
    }
}

struct MuscleGroupStatus: Identifiable {
    let id = UUID()
    let name: String
    let emoji: String
    let daysAgo: Int?     // nil = никогда
    let windowDays: Int   // = 10

    var state: MuscleState {
        guard let d = daysAgo else { return .never }
        if d <= windowDays - 3 { return .done }
        if d <= windowDays     { return .warning }
        return .missed
    }

    var label: String {
        guard let d = daysAgo else { return "✗ никогда" }
        if d == 0 { return "✓ сегодня" }
        if state == .done    { return "✓ \(d) дн. назад" }
        if state == .warning { return "⚠ \(d) дн. назад" }
        return "✗ \(d) дн. назад"
    }

    var color: String {
        switch state {
        case .done:    return "green"
        case .warning: return "yellow"
        case .missed:  return "red"
        case .never:   return "red"
        }
    }

    enum MuscleState { case done, warning, missed, never }
}

struct PRGoal: Identifiable {
    let id = UUID()
    let exerciseName: String
    let emoji: String
    let currentKg: Double
    let goalKg: Double

    var progress: Double { min(1.0, currentKg / goalKg) }
    var remaining: Double { max(0, goalKg - currentKg) }
    var isAchieved: Bool { currentKg >= goalKg }
}

// MARK: - Gamification Manager

struct GamificationManager {
    static let windowDays = 10
    static let weeklyGoal = 3

    static func weeklyStreak(workouts: [Workout]) -> WeeklyStreak {
        let cal = Calendar.current
        let finished = workouts.filter { $0.finishedAt != nil }

        // completed this week
        let startOfWeek = cal.date(from: cal.dateComponents([.yearForWeekOfYear, .weekOfYear], from: Date())) ?? Date()
        let thisWeekCount = finished.filter { $0.date >= startOfWeek }.count

        // week history (last 7 weeks)
        var history: [Bool] = []
        for weekOffset in stride(from: -6, through: -1, by: 1) {
            guard let ws = cal.date(byAdding: .weekOfYear, value: weekOffset, to: startOfWeek),
                  let we = cal.date(byAdding: .weekOfYear, value: weekOffset + 1, to: startOfWeek) else { continue }
            let count = finished.filter { $0.date >= ws && $0.date < we }.count
            history.append(count >= weeklyGoal)
        }

        // current streak (count consecutive completed weeks going back)
        var streak = 0
        for completed in history.reversed() {
            if completed { streak += 1 } else { break }
        }

        // record streak
        var maxStreak = 0
        var cur = 0
        for completed in history {
            cur = completed ? cur + 1 : 0
            maxStreak = max(maxStreak, cur)
        }
        maxStreak = max(maxStreak, streak)

        // days left in week
        let weekday = cal.component(.weekday, from: Date())
        let daysLeft = max(0, 8 - weekday) // 1=Sun→7, Mon=2→6 days left

        return WeeklyStreak(
            current: streak,
            record: max(maxStreak, streak),
            completedThisWeek: thisWeekCount,
            goalPerWeek: weeklyGoal,
            weekHistory: history,
            daysLeftInWeek: daysLeft
        )
    }

    static func muscleStatuses(workouts: [Workout]) -> [MuscleGroupStatus] {
        let cal = Calendar.current
        let now = Date()
        let finished = workouts.filter { $0.finishedAt != nil }

        let groups: [(String, String, String)] = [
            ("Ноги", "🦵", "Ноги"),
            ("Грудь", "🫁", "Грудь"),
            ("Спина", "🔙", "Спина"),
            ("Руки", "💪", "Руки"),
            ("Плечи", "🙆", "Плечи"),
            ("Пресс", "🔥", "Пресс"),
        ]

        return groups.map { (name, emoji, bodyPart) in
            // find the most recent workout that included this body part
            let lastDate = finished
                .filter { w in
                    w.workoutExercises.contains { we in
                        we.exercise.bodyPart.lowercased() == bodyPart.lowercased() &&
                        we.workoutSets.contains { $0.isCompleted }
                    }
                }
                .map { $0.date }
                .max()

            let daysAgo = lastDate.map { cal.dateComponents([.day], from: $0, to: now).day ?? 0 }

            return MuscleGroupStatus(name: name, emoji: emoji, daysAgo: daysAgo, windowDays: windowDays)
        }
    }

    static func xpTotal(workouts: [Workout]) -> Int {
        let finished = workouts.filter { $0.finishedAt != nil }
        let workoutXP = finished.count * 50
        // PR XP is harder to compute without context here, approximate
        return workoutXP
    }

    static let levels: [(Int, String, String)] = [
        (0,    "Новичок",   "🌱"),
        (300,  "Любитель",  "💧"),
        (700,  "Спортсмен", "⚡"),
        (1400, "Атлет",     "🔥"),
        (2500, "Элита",     "💎"),
        (4000, "Легенда",   "👑"),
    ]

    static func level(xp: Int) -> (name: String, emoji: String, level: Int, progressInLevel: Double, xpForNext: Int, xpAtStart: Int) {
        var current = levels[0]
        var next = levels[1]
        var levelNum = 1

        for i in 0..<levels.count {
            if xp >= levels[i].0 {
                current = levels[i]
                levelNum = i + 1
                next = i + 1 < levels.count ? levels[i + 1] : levels[i]
            }
        }

        let range = Double(next.0 - current.0)
        let progress = range > 0 ? Double(xp - current.0) / range : 1.0
        return (current.1, current.2, levelNum, min(1, progress), next.0, current.0)
    }
}
